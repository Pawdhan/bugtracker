package com.flightapp.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.flightapp.domain.Airline;
import com.flightapp.domain.AirlineSchedules;
import com.flightapp.domain.FlightSchedules;
import com.flightapp.exception.FlightAdminException;
import com.flightapp.repository.AirlineRepository;
import com.flightapp.repository.AirlineScheduleRepository;

@Service
public class ManageAirlineServiceImpl implements ManageAirlineService {
	@Autowired
	private AirlineRepository airlineRepo;
	@Autowired
	private AirlineScheduleRepository airlineScheduleRepo;
	
	
	@Override
	public Airline addAirline(Airline airline) throws FlightAdminException {
		try {

			Assert.notNull(airline, "Data cannot be null");
			return airlineRepo.save(airline);
			
		} catch (Exception e) {
			throw new FlightAdminException(e.getMessage());
		}

	}

	@Override
	public AirlineSchedules addAirlineSchedule(AirlineSchedules airlineSchedule) throws FlightAdminException {
		try {

			Assert.notNull(airlineSchedule, "Data cannot be null");
			Assert.notNull(airlineSchedule.getFlightNumber(), "Flight Number cannot be null");
			return airlineScheduleRepo.save(airlineSchedule);
			
		} catch (Exception e) {
			throw new FlightAdminException(e.getMessage());
		}
	}

	@Override
	public List<Airline> getAirlines() {

		return airlineRepo.findAll();
		
	}

	@Override
	public List<AirlineSchedules> getAirlineSchedules(String airline, int flightNumber, String instrumentUsed) throws FlightAdminException {

		try {
			return airlineScheduleRepo.findByAirlineAndFlightNumberAndInstrumentUsed(airline, flightNumber, instrumentUsed);
		} catch (Exception e) {
			throw new FlightAdminException(e.getMessage());
		}
	}

	@Override
	public Airline getAirlineByFlightNumber(int flightNumber) {
		return airlineRepo.findByFlightNumber(flightNumber);
	}

	@Override
	public List<String> getListOfAirlines() {
		List<Airline> airlines = airlineRepo.findAll();
		return airlines.stream().map(air -> air.getAirline()).collect(Collectors.toList());
		
	}

	@Override
	public FlightSchedules getflightschedules(boolean oneWay, String fromPlace, String toPlace, String startDate,
			String endDate) throws FlightAdminException {

		try {
			Assert.notNull(oneWay, "Data cannot be null");
			Assert.hasText(fromPlace, "From Place cannot be null");
			Assert.hasText(startDate, "Start Date cannot be null");
			FlightSchedules flightSchedules = new FlightSchedules();
			flightSchedules.setOnwardSchedules(airlineScheduleRepo.findByFromPlaceAndToPlaceAndStartDate(fromPlace, toPlace, LocalDate.parse(startDate)));
			if(!oneWay) {
				flightSchedules.setReturnSchedules(airlineScheduleRepo.findByFromPlaceAndToPlaceAndStartDate(toPlace, fromPlace, LocalDate.parse(endDate)));			
			}
			return flightSchedules;
			
		} catch (Exception e) {
			throw new FlightAdminException(e.getMessage());
		}
	}

}
