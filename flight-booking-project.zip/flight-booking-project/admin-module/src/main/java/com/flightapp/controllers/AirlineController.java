package com.flightapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.flightapp.domain.Airline;
import com.flightapp.domain.AirlineSchedules;
import com.flightapp.domain.FlightSchedules;
import com.flightapp.exception.FlightAdminException;
import com.flightapp.service.ManageAirlineService;

@RestController
@RequestMapping("airline")
@CrossOrigin
public class AirlineController {

	@Autowired
	private ManageAirlineService manageAirlineService;
	
	@PostMapping("/register")
	public Airline addAirline(@RequestBody Airline airline) throws FlightAdminException {
		System.err.println("inside addAirlineSchedule: " + airline);
		return manageAirlineService.addAirline(airline);
	}
	
	@PostMapping("/inventory/add")
	public AirlineSchedules addAirlineSchedule(@RequestBody AirlineSchedules airlineSchedule) throws FlightAdminException {
		System.err.println("inside addAirlineSchedule: " + airlineSchedule);
		return manageAirlineService.addAirlineSchedule(airlineSchedule);
	}
	
	@GetMapping("/getairlines")
	public List<Airline> getAirlines() throws FlightAdminException {
		System.err.println("inside getAirlines: ");
		return manageAirlineService.getAirlines();
	}
	
	@GetMapping("/getlistofairlines")
	public List<String> getListOfAirlines() throws FlightAdminException {
		System.err.println("inside getAirlines: ");
		return manageAirlineService.getListOfAirlines();
	}
	
	@GetMapping("/getairlinebyflightnumber/{flightNumber}")
	public Airline getAirlineByFlightNumber(@PathVariable int flightNumber) throws FlightAdminException {
		System.err.println("inside getAirlineByFlightNumber: ");
		return manageAirlineService.getAirlineByFlightNumber(flightNumber);
	}
	
	@GetMapping("/getschedulesbyfilter")
	public List<AirlineSchedules> getAirlineSchedules(@RequestParam("airline") String airline, @RequestParam("flightnumber") int flightNumber, @RequestParam("instrument") String instrumentUsed) throws FlightAdminException {
		System.err.println("inside getAirlineSchedules: " + airline +  flightNumber + instrumentUsed);
		return manageAirlineService.getAirlineSchedules(airline, flightNumber, instrumentUsed);
	}
	
	@GetMapping("/getflightschedules")
	public FlightSchedules getflightschedules(@RequestParam("oneWay") boolean oneWay,
			@RequestParam("fromPlace") String fromPlace, @RequestParam("toPlace") String toPlace,
			@RequestParam("startDate") String startDate, @RequestParam("endDate") String endDate) throws FlightAdminException {
		System.err.println("inside getflightschedules: ");
		return manageAirlineService.getflightschedules(oneWay, fromPlace, toPlace, startDate, endDate);
	}
	
}
