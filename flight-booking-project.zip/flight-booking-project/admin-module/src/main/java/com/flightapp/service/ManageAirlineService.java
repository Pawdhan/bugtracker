package com.flightapp.service;

import java.util.List;

import com.flightapp.domain.Airline;
import com.flightapp.domain.AirlineSchedules;
import com.flightapp.domain.FlightSchedules;
import com.flightapp.exception.FlightAdminException;

public interface ManageAirlineService {

	Airline addAirline(Airline airline) throws FlightAdminException;

	AirlineSchedules addAirlineSchedule(AirlineSchedules airlineSchedule) throws FlightAdminException;

	List<Airline> getAirlines();

	List<AirlineSchedules> getAirlineSchedules(String airline, int flightNumber, String instrumentUsed) throws FlightAdminException;

	Airline getAirlineByFlightNumber(int flightNumber);

	List<String> getListOfAirlines();

	FlightSchedules getflightschedules(boolean oneWay, String fromPlace, String toPlace, String startDate,
			String endDate) throws FlightAdminException;

}
