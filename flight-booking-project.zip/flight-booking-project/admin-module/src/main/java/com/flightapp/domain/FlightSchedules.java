package com.flightapp.domain;

import java.util.List;

public class FlightSchedules {

	private List<AirlineSchedules> onwardSchedules;
	private List<AirlineSchedules> returnSchedules;
	public List<AirlineSchedules> getOnwardSchedules() {
		return onwardSchedules;
	}
	public void setOnwardSchedules(List<AirlineSchedules> onwardSchedules) {
		this.onwardSchedules = onwardSchedules;
	}
	public List<AirlineSchedules> getReturnSchedules() {
		return returnSchedules;
	}
	public void setReturnSchedules(List<AirlineSchedules> returnSchedules) {
		this.returnSchedules = returnSchedules;
	}
	
}
