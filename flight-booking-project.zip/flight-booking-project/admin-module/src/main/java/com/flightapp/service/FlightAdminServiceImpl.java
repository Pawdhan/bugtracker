package com.flightapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.flightapp.domain.Admin;
import com.flightapp.domain.User;
import com.flightapp.exception.FlightAdminException;
import com.flightapp.repository.UserRepository;

@Service
public class FlightAdminServiceImpl implements FlightAdminService{
	
	@Autowired
	private UserRepository userRepository;
	
	@Override
	public Admin adminLogin(Admin admin) throws FlightAdminException {
		try {
			Assert.notNull(admin, "Cannot be null");
			if(admin.getEmail().equals("admin") && admin.getPassword().equals("123")) {
				return admin;
			} else {
				throw new FlightAdminException("Invalid username or password!");
			}
		} catch (Exception e) {
			throw new FlightAdminException(e.getMessage());
		}
	}

	@Override
	public User userSignUp(User user) throws FlightAdminException {
		try {

			Assert.notNull(user, "User data cannot be null");
			Assert.hasText(user.getEmail(), "Email cannot be null");
			Assert.hasText(user.getName(), "Name cannot be null");
			Assert.hasText(user.getPassword(), "Password cannot be null");
			if(userRepository.existsByEmail(user.getEmail())) {
				throw new FlightAdminException("User with given mail id already exists!");
			}
			return userRepository.save(user);
		} catch (Exception e) {
			throw new FlightAdminException(e.getMessage());
		}
		
	}

	@Override
	public User userSignIn(String email, String password) throws FlightAdminException {
		try {
			Assert.hasText(email, "Email cannot be null");
			Assert.hasText(password, "Name cannot be null");
			User user = userRepository.findByEmail(email);
			if(user !=null && user.getPassword().equals(password)) {
				return user;
			} else {
				throw new FlightAdminException("Invalid username or password!");
			}
		} catch (Exception e) {
			throw new FlightAdminException(e.getMessage());
		}
	}

}
