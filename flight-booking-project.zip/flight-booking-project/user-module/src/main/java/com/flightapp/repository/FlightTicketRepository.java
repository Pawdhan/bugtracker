package com.flightapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.flightapp.domain.FlightTicket;

public interface FlightTicketRepository extends JpaRepository<FlightTicket, Integer>{

	List<FlightTicket> findByEmail(String email);

	List<FlightTicket> findByEmailAndStatus(String email, String string);

}
