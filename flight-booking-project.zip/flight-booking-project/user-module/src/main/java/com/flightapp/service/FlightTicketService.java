package com.flightapp.service;

import java.util.List;

import com.flightapp.domain.FlightTicket;
import com.flightapp.exception.FlightAdminException;

public interface FlightTicketService {

	FlightTicket bookFlightTicket(FlightTicket flightTicket) throws FlightAdminException;

	List<FlightTicket> getUserBookings(String email);

	List<FlightTicket> getActiveUserBookings(String email);

}
