package com.flightapp.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class FlightTicket {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int pnrNumber;
	private String onwardAirline;
	private String returnAirline;
	private String status;
	private String userName;
	private String email;
	private String meal;
	private int noOfSeats;
	private String trip;
	private String seatNumber;
	private double cost;
	
	public int getPnrNumber() {
		return pnrNumber;
	}
	public void setPnrNumber(int pnrNumber) {
		this.pnrNumber = pnrNumber;
	}
	public String getOnwardAirline() {
		return onwardAirline;
	}
	public void setOnwardAirline(String onwardAirline) {
		this.onwardAirline = onwardAirline;
	}
	public String getReturnAirline() {
		return returnAirline;
	}
	public void setReturnAirline(String returnAirline) {
		this.returnAirline = returnAirline;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMeal() {
		return meal;
	}
	public void setMeal(String meal) {
		this.meal = meal;
	}
	public int getNoOfSeats() {
		return noOfSeats;
	}
	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}
	public String getTrip() {
		return trip;
	}
	public void setTrip(String trip) {
		this.trip = trip;
	}
	public String getSeatNumber() {
		return seatNumber;
	}
	public void setSeatNumber(String seatNumber) {
		this.seatNumber = seatNumber;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	
	
}
