package com.flightapp.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.flightapp.domain.FlightTicket;
import com.flightapp.exception.FlightAdminException;
import com.flightapp.repository.FlightTicketRepository;

@Service
public class FlightTicketServiceImpl implements FlightTicketService {

	@Autowired
	private FlightTicketRepository flightTicketRepo;
	
	
	@Override
	public FlightTicket bookFlightTicket(FlightTicket flightTicket) throws FlightAdminException {
		try {
			Assert.notNull(flightTicket, "Data cannot be null");
			return flightTicketRepo.save(flightTicket);
			
		} catch (Exception e) {
			throw new FlightAdminException(e.getMessage());
		}

	}

	@Override
	public List<FlightTicket> getUserBookings(String email) {
		return flightTicketRepo.findByEmail(email);
	}


	@Override
	public List<FlightTicket> getActiveUserBookings(String email) {
		return flightTicketRepo.findByEmailAndStatus(email, "ACTIVE");
	}


}
