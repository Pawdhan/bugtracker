package com.flightapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flightapp.domain.FlightTicket;
import com.flightapp.exception.FlightAdminException;
import com.flightapp.service.FlightTicketService;

@RestController
@RequestMapping("booking")
@CrossOrigin
public class UserFlightController {

	@Autowired
	private FlightTicketService flightTicketService;

	@PostMapping("/newticket")
	public FlightTicket bookFlightTicket(@RequestBody FlightTicket flightTicket) throws FlightAdminException {
		System.err.println("inside bookFlightTicket" + flightTicket);
		return flightTicketService.bookFlightTicket(flightTicket);
	}
	
	
	@GetMapping("/getuserbookings/{email}")
	public List<FlightTicket> getUserBookings(@PathVariable String email) throws FlightAdminException {
		System.err.println("inside getUserBookings: ");
		return flightTicketService.getUserBookings(email);
	}
	
	@GetMapping("/getactivebookings/{email}")
	public List<FlightTicket> getActiveUserBookings(@PathVariable String email) throws FlightAdminException {
		System.err.println("inside getUserBookings: ");
		return flightTicketService.getActiveUserBookings(email);
	}
}
